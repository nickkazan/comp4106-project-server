# comp4106-project-server
An OCR project for Comp4106
